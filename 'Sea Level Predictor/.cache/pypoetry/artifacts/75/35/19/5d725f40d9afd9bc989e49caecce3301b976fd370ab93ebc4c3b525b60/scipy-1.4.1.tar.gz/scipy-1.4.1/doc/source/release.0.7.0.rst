.. include:: ../release/0.7.0-notes.rst
