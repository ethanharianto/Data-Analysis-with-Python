.. _adding-new:

Adding New Methods, Functions, and Classes
==========================================


While adding code to SciPy is in most cases quite straight forward, there are a few places where that is not the case.
This document contains detailed information on some specific situations where
it may not be clear from the outset what is involved in the task.

.. include:: adding_new/new_stats_distribution.rst.inc
