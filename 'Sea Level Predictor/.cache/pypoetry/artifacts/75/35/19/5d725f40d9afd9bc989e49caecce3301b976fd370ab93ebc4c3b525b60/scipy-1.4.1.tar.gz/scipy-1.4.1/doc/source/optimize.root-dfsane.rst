.. _optimize.root-dfsane:

root(method='df-sane')
--------------------------------------------

.. scipy-optimize:function:: scipy.optimize.root
   :impl: scipy.optimize._spectral._root_df_sane
   :method: df-sane
