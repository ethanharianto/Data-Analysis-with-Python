.. include:: ../release/1.2.2-notes.rst
