.. _optimize.minimize-dogleg:

minimize(method='dogleg')
----------------------------------------

.. scipy-optimize:function:: scipy.optimize.minimize
   :impl: scipy.optimize._trustregion_dogleg._minimize_dogleg
   :method: dogleg
