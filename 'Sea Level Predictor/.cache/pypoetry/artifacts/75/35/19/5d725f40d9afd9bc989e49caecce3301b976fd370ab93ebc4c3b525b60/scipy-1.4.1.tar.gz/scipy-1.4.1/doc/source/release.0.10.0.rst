.. include:: ../release/0.10.0-notes.rst
